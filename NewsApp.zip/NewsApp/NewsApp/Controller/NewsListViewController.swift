//
//  ViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import UIKit
import SafariServices

class NewsListViewController: UIViewController {
    
    @IBOutlet weak var newsTableView: UITableView!
    
    var refreshControl = UIRefreshControl()
    var viewModel = NewsListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupProperties()
    }
    
    func setupProperties() {
        let coidButton = UIBarButtonItem(title: "Covid Tracker", style: .plain, target: self, action: #selector(covidButtonTapped))
        self.navigationItem.rightBarButtonItem = coidButton
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([.font : UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor : UIColor.black], for: .normal)
        
        self.newsTableView.addSubview(self.refreshControl)
        self.refreshControl.addTarget(self, action: #selector(self.getNewsData), for: .valueChanged)
        self.getNewsData()
    }
    
    @objc func covidButtonTapped() {
        guard let covidViewController = UIStoryboard.init(name: Constants.mainStorybaord, bundle: Bundle.main).instantiateViewController(withIdentifier: "CovidViewController") as? CovidViewController else {
            return
        }
        self.navigationController?.pushViewController(covidViewController, animated: true)
    }
    
    @objc func getNewsData() {
        self.viewModel.getNewsData { (status, error) in
            DispatchQueue.main.async {
                self.newsTableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }
    }
}

extension NewsListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.cellViewModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.newsCellReuseId, for: indexPath) as? NewsCell else {
            return UITableViewCell()
        }
        let article = viewModel.cellViewModel[indexPath.row]
        cell.cellVM = article
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let article = self.viewModel.newsArticles[indexPath.row]
        guard let url = URL(string: article.url ?? "") else {
            return
        }
        let config = SFSafariViewController.Configuration()
        let safariViewController = SFSafariViewController(url: url, configuration: config)
        safariViewController.modalPresentationStyle = .formSheet
        present(safariViewController, animated: true)
    }
}
