//
//  NewsModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation

// MARK: - NewsModel
struct NewsModel: Codable {
    let articles: [Article]
}

// MARK: - Article
struct Article: Codable {
    let title: String?
    let articleDescription: String?
    let url: String?
    let urlToImage: String?

    enum CodingKeys: String, CodingKey {
        case title
        case articleDescription = "description"
        case url, urlToImage
    }
}
