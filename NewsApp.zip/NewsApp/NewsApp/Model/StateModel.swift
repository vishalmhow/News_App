//
//  StateModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

// MARK: - StateListResponse
struct StateListResponse: Codable {
    let data: [State]
}

// MARK: - State
struct State: Codable {
    let name: String
    let state_code: String
}
