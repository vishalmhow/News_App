//
//  Services.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation
import UIKit

let imageCache = NSCache<AnyObject, AnyObject>()

protocol NewsServiceable {
    func fetchNewsListWithAsyncURLSession() async throws -> [Article]
    func downloadImageWithAsyncURLSession(imageUrl: URL) async throws -> UIImage
    func fetchStateListWithAsyncURLSession() async throws -> [State]
    func fetchCovidDataWithAsyncURLSession(url: URL) async throws -> [DayData]
}

class NewsServices: NewsServiceable {
    
    func fetchNewsListWithAsyncURLSession() async throws -> [Article] {
        
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        
        guard let url = URL(string: "\(APIDetails.baseUrl)\(APIDetails.urlKey)") else {
            throw NetworkError.apiFailure
        }
        
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
            throw NetworkError.invalidStatusCode
        }
        let newsData = try JSONDecoder().decode(NewsModel.self, from: data)
        
        return newsData.articles
    }
    
    func downloadImageWithAsyncURLSession(imageUrl: URL) async throws -> UIImage {
        
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        
        // Check If Image is avvailable in Cache
        if let imageFromCache = imageCache.object(forKey: imageUrl.absoluteString as AnyObject) as? UIImage {
            return imageFromCache
        }
        // Use the async variant of URLSession to fetch data
        
        let (data, _) = try await URLSession.shared.data(from: imageUrl)
        
        guard let downloadedImage = UIImage(data: data) else {
            throw NetworkError.apiFailure
        }
        imageCache.setObject(downloadedImage, forKey: imageUrl.absoluteString as AnyObject)
        
        return downloadedImage
    }
    
    func fetchStateListWithAsyncURLSession() async throws -> [State] {
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        
        guard let url = APIDetails.covidStateUrl else {
            throw NetworkError.apiFailure
        }
        
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
            throw NetworkError.invalidStatusCode
        }
        let result = try JSONDecoder().decode(StateListResponse.self, from: data)
        
        return result.data
    }
    
    func fetchCovidDataWithAsyncURLSession(url: URL) async throws -> [DayData] {
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
            throw NetworkError.invalidStatusCode
        }
        let result = try JSONDecoder().decode(CovidDataResponse.self, from: data)
        
        let models: [DayData] = result.data.compactMap {
            guard let date = DateFormatter.dayFormatter.date(from: $0.date), let value = $0.cases?.total.value else {
                return nil
            }
            
            return DayData(date: date, count: value)
        }
        return models
    }
}

extension URLSession {
    func data(from url: URL) async throws -> (Data, URLResponse) {
         try await withCheckedThrowingContinuation { continuation in
            let task = self.dataTask(with: url) { data, response, error in
                 guard let data = data, let response = response else {
                     let error = error ?? URLError(.badServerResponse)
                     return continuation.resume(throwing: error)
                 }

                 continuation.resume(returning: (data, response))
             }

             task.resume()
        }
    }
}
