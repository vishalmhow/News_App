//
//  FilterCell.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit

class FilterCell: UITableViewCell {
    
    @IBOutlet weak var stateNameLabel: UILabel!
    
}
