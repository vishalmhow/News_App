//
//  CovidViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
import Charts

class CovidViewModel: NSObject {
    var scope: DataScope  = .national
    var dayData = [DayData]()
    var covidTrackingUrl: String = APIDetails.covidTrackingUrl
    var service: NewsServices? = NewsServices()
    
    let numberFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.usesGroupingSeparator = true
        formatter.groupingSeparator = ","
        formatter.formatterBehavior =  .default
        formatter.locale = .current
        return formatter
    }()
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    
    func getFilterButtonTitle() -> String {
        switch scope {
        case .national:
            covidTrackingUrl = "https://api.covidtracking.com/v2/us/daily.json"
            return "National"
        case .state(let state):
            covidTrackingUrl = "https://api.covidtracking.com/v2/states/\(state.state_code.lowercased())/daily.json"
            return state.name
        }
    }
    
    func fetchCovidData (completion: @escaping((Bool, Error?) -> Void)) {
        Task {
            do {
                dayData = try await service!.fetchCovidDataWithAsyncURLSession(url: URL(string: covidTrackingUrl)!)
                completion(true, nil)
            } catch {
                print(error.localizedDescription)
                completion(false, error)
            }
        }
    }
    
    func getStringFromDate(dayData: DayData) -> String {
        let dateString =  DateFormatter.prettyFormatter.string(from: dayData.date)
        let total = self.numberFormatter.string(from: NSNumber(value: dayData.count))
        
        return "\(dateString): \(total ?? "\(dayData.count)")"
    }
    
    func setupBarChartView() -> BarChartData {
        var entries: [BarChartDataEntry] = []
        
        let subSet = dayData.prefix(20)
        
        for index in 0..<subSet.count {
            let data = subSet[index]
            entries.append(.init(x: Double(index), y: Double(data.count)))
        }
        let dataSet = BarChartDataSet(entries: entries)
        dataSet.colors = ChartColorTemplates.joyful()
        // ChartColorTemplate
        let data: BarChartData = BarChartData(dataSet: dataSet)
        
        return data
    }
    
}

