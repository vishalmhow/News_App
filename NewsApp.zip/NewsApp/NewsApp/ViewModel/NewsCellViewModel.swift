//
//  NewsCellViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

struct NewsCellViewModel {
    let article: Article
    var title: String {
        return article.title ?? ""
    }
    var description: String {
        return article.articleDescription ?? ""
    }
    var webUrl: String {
        return article.url ?? ""
    }
    var imageUrl: String {
        return article.urlToImage ?? ""
    }
}
