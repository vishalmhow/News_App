//
//  NewsListViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation
import UIKit

class NewsListViewModel: ObservableObject {
    
    var newsArticles: [Article] = []
    var cellViewModel = [NewsCellViewModel]()
    var service: NewsServices? = NewsServices()
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    
    func getNewsData(completion: @escaping((Bool, Error?) -> Void)) {
        Task {
            do {
                newsArticles = try await service!.fetchNewsListWithAsyncURLSession()
                let cellVM = newsArticles.map(NewsCellViewModel.init)
                DispatchQueue.main.async {
                    self.cellViewModel = cellVM
                }
                completion(true, nil)
            } catch {
                completion(false, error)
                print(error.localizedDescription)
            }
        }
    }
    
    func getImageFromUrl(imageUrl: URL, completion: @escaping((UIImage) -> Void)) {
        Task {
            do {
                let downloadedImage = try await service!.downloadImageWithAsyncURLSession(imageUrl: imageUrl) as UIImage?
                if let downloadedImage = downloadedImage {
                    completion(downloadedImage)
                }
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}
