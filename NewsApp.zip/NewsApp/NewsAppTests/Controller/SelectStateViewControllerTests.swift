//
//  SelectStateViewControllerTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import XCTest
@testable import NewsApp

class SelectStateViewControllerTests: XCTestCase {

    var newsServices: MockNewsServices!
    var viewModel: SelectStateViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        try super.setUpWithError()
        
        newsServices = MockNewsServices()
        viewModel = SelectStateViewModel(service: newsServices)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        newsServices = nil
        viewModel = nil
        
        try super.tearDownWithError()
    }
    
    func testFetchCovidDataSuccess() throws {
        
        newsServices.response = newsServices.mockStateData()
        
        viewModel.fetchStateList { (status, error) in
            XCTAssertTrue(status)
        }
    }
    
    func testFetchCovidDataFailureAPIError() throws {
        
        let response = NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "API Error occurred"])
        newsServices.response = response
        
        viewModel.fetchStateList { (status, error) in
            XCTAssertTrue(error != nil)
        }
    }
    
    
}
